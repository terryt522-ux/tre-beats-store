export default function Cancel() {
  return <div className="prose"><h1>Payment canceled</h1><p>No charge was made.</p></div>;
}