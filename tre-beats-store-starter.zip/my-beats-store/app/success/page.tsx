export default function Success() {
  return <div className="prose"><h1>Thanks!</h1><p>Your payment was successful. Check your email for the download link.</p></div>;
}